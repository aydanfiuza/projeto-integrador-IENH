<?php


    $user = 'root';
    $senha = '';
    

    $conexao = new PDO('mysql:host=127.0.0.1:1360;dbname=projeto_integrador', $user, $senha);


    // $ids = [1,2,3,4,5,6,7,8,9,10];
    // $nomes = ['joao','mario','fabricio','pedro','lucas','jose','cristian','marcos','luciano','felipe'];
    // $emails = ['joao@gmail.com','mario@gmail.com','fabricio@gmail.com','pedro@gmail.com','lucas@gmail.com','jose@gmail.com','cristian@gmail.com','marcos@gmail.com','luciano@gmail.com','felipe@gmail.com'];
    // $senhas = ['joao123456','mario123456','fabricio123456','pedro123456','lucas123456','jose123456','cristian123456','marcos123456','luciano123456','felipe123456'];

    // // $mysqli = new mysqli('127.0.0.1:1360', 'root', '', 'projeto_integrador');

    // $stmt = $conexao->prepare("INSERT INTO usuario (id, nome, email, senha) VALUES (:id, :nome, :email, :senha)");

    // for ($i = 0; $i < 10; $i++) {
    //     $stmt->bindParam(':id', $ids[$i]);
    //     $stmt->bindParam(':nome', $nomes[$i]);
    //     $stmt->bindParam(':email', $emails[$i]);
    //     $stmt->bindParam(':senha', $senhas[$i]);

    //     $stmt->execute();

    // }


?>