<?php
// Iniciando a sessão
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_cache_expire(30); // Definindo o prazo para expirar a sessão em 30 minutos
    session_start();
}
    $user = 'root';
    $senha = '';


    $conexao = new PDO('mysql:host=127.0.0.1:1360;dbname=projeto_integrador', $user, $senha);


    $query = $conexao->prepare("SELECT * FROM usuario");

    $query->execute();

    $res = $query->fetchAll();


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table, th, td {
            border: 1px solid black;
        }

    </style>
</head>
<body>
    <?php $frase = "ola mundo" ?>
    <div>a frase é: <?= $frase ?></div>
    <div>a frase invertida é <?= strrev($frase) ?></div>

    <?php if (!isset($_SESSION['usuario'])): ?>
        <h1>VOCE NAO ESTA LOGADO!!!!!</h1>
    <?php else: ?>
        <h1>OLÁ <?= $_SESSION['usuario'] ?></h1>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nome</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($res as $dado): ?>
                <tr>
                    <td><?= $dado['id'] ?></td> 
                    <td><?= $dado['nome'] ?></td> 
                    <td><?= $dado['email'] ?></td>
                </tr>
            <?php endforeach; ?>

        </tbody>
    </table>
</body>
</html>